# Pipeline

[![Issue Count](https://codeclimate.com/github/CSGOFlair/dev/badges/issue_count.svg)](https://codeclimate.com/github/CSGOFlair/dev)
[![License](https://img.shields.io/badge/License-GPL--3.0-blue.svg?style=flat-square)](https://www.gnu.org/licenses/gpl-3.0.txt)
![Version](https://img.shields.io/badge/Version-0.1%20Beta-yellow.svg?style=flat-square)
[![GPA](https://img.shields.io/badge/GPA-3.5-yellowgreen.svg?style=flat-square)](https://codeclimate.com/github/CSGOFlair/dev)
[![Gitter](https://img.shields.io/badge/Chat%20on%20Gitter-Join-00ffe9.svg?style=flat-square)](https://gitter.im/CSGOFlair/Lobby?utm_source=share-link&utm_medium=link&utm_campaign=share-link)

A website for all things CSGO development.

[THE URL](https://csgoflair.github.io/dev/) (csgoflair.github.io is set up to redir)

[THE GITTER](https://gitter.im/csgo-schema-test/Lobby?utm_source=share-link&utm_medium=link&utm_campaign=share-link)

Stuff we're working on:

- [ ] Finish [Docs Page Templates](https://github.com/CSGOFlair/Page-Templates)
- [X] Minimize all Code Climate errors
- [ ] Navbar dropdown
